__version_info__ = (2, 4, 1)
__version__ = '.'.join(map(str, __version_info__))
